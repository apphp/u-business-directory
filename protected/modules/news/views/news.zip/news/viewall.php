<?php 
	$this->_activeMenu = 'news/viewAll';
    $this->_pageTitle = A::t('news', 'All News');
?>

<h1 class="title"><?php echo  A::t('news', 'All News'); ?></h1>
<div class="block-body">                       
    
<?php
    if($actionMessage != ''){
        echo $actionMessage;
    }else{    
        $showNews = count($news);
        for($i=0; $i < $showNews; $i++){
			$newsLink = Website::prepareLinkByFormat('news', 'news_link_format', $news[$i]['id'], $news[$i]['news_header']);
?>
        <h3><a href="<?php echo $newsLink; ?>"><?php echo $news[$i]['news_header']; ?></a></h3>
        <div class="news-text">
			<?php echo !empty($news[$i]['intro_image']) ? '<img class="news-intro-thumb" src="images/modules/news/intro_images/'.CHtml::encode($news[$i]['intro_image']).'" alt="news intro" />' : ''; ?>
			<?php echo $news[$i]['news_text']; ?>
		</div>    
        <div class="news-info"><?php echo A::t('news', 'Published at').': '.date($dateTimeFormat, strtotime($news[$i]['created_at'])); ?></div>
        <div class="news-divider"></div>
<?php
        }        

        if($totalNews > 1){
            echo CWidget::create('CPagination', array(
                'actionPath'   => 'news/viewAll',
                'currentPage'  => $currentPage,
                'pageSize'     => $pageSize,
                'totalRecords' => $totalNews,
                'showResultsOfTotal' => false,
                'linkType' => 0,
                'paginationType' => 'justNumbers'
            ));            
        }
    }
?>    
</div>
