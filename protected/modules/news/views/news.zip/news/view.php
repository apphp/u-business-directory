<?php 
    $this->_pageTitle = $newsHeader;
?>

<?php echo $actionMessage; ?>

<h1 class="title"><?php echo $newsHeader; ?></h1>
<div class="block-body">	
    <div class="news-text">
		<?php echo !empty($introImage) ? '<img class="news-intro-image" src="images/modules/news/intro_images/'.CHtml::encode($introImage).'" alt="news intro" />' : '' ; ?>
		<?php echo $newsText; ?>
	</div>
    <div class="news-info"><?php echo A::t('news', 'Published at').': '.$datePublished; ?></div>
</div>

