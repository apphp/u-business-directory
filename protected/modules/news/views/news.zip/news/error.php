<?php 
    $this->_pageTitle = $errorHeader.' | '.CConfig::get('name')
?>

<h1 class="title"><?php echo $errorHeader; ?></h1>
<div class="block-body">                       
    <p class="news-text"><?php echo $errorText; ?></p>
</div>

